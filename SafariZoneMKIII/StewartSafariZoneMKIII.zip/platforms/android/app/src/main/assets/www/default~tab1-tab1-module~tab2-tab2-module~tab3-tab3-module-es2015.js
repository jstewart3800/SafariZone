(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~tab1-tab1-module~tab2-tab2-module~tab3-tab3-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/components/log/log.component.html":
/*!*****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/log/log.component.html ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-row>\r\n   <ion-col>\r\n      <ion-list>\r\n         <div *ngFor=\"let p of logList\">\r\n            <ion-item *ngIf=\"p.discovered === 't'; else pokeKnown\">\r\n               <p slot=\"start\" class='mb-0'>???</p>\r\n               <ion-label>???</ion-label>\r\n               <ion-thumbnail slot=\"end\">\r\n                  <img src=\"assets/icon/mysteryIcon.png\">\r\n               </ion-thumbnail>\r\n            </ion-item>\r\n            <ng-template #pokeKnown>\r\n               <ion-item (click)=\"presentModal(p)\">\r\n                  <p slot=\"start\" class='mb-0'>{{p.dexNum}}</p>\r\n                  <ion-label>{{p.pokemon}}</ion-label>\r\n                  <ion-thumbnail slot=\"end\">\r\n                     <img src=\"assets/icon/{{p.pokemon}}Icon.png\">\r\n                  </ion-thumbnail>\r\n               </ion-item>\r\n            </ng-template>\r\n         </div>\r\n      </ion-list>\r\n   </ion-col>\r\n</ion-row>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/components/log/modal/modal.component.html":
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/log/modal/modal.component.html ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header [translucent]=\"true\">\n   <ion-grid class=\"headerStyle\">\n      <ion-row>\n         <ion-col class=\"headerButts\">\n            <div class=\"searchButt\" (click)=\"close()\">\n               <ion-icon name=\"close-sharp\"></ion-icon>\n            </div>\n            <div class=\"miniButt logButt whiteText\"></div>\n            <div class=\"miniButt accountButt\"></div>\n            <div class=\"miniButt settingsButt whiteText\"></div>\n         </ion-col>\n         <ion-col size=\"4\"></ion-col>\n      </ion-row>\n   </ion-grid>\n</ion-header>\n\n<div class=\"ion-text-center modalScroll\">\n\n   <ion-card>\n      <ion-grid>\n\n         <ion-row>\n            <ion-col>\n               <div>\n                  <img class=\"dexSprite\" src=\"assets/wildSprites/{{entryNum}}.png\" alt=\"{{entryName}}\">\n               </div>\n               <ion-card-header class=\"p-0\">\n                  <ion-card-title>{{entryName}}</ion-card-title>\n                  <ion-card-subtitle class=\"blackText\">#{{entryNum}}</ion-card-subtitle>\n               </ion-card-header>\n            </ion-col>\n         </ion-row>\n\n         <hr>\n\n         <ion-row>\n            <ion-col>\n               <ion-card-subtitle class=\"mb-2 blackText underline\">\n                  Base Stats:\n               </ion-card-subtitle>\n            </ion-col>\n         </ion-row>\n\n         <ion-row class=\"blackText\">\n            <ion-col class=\"statBox\" id=\"hpBox\">\n               <p>\n                  Hp\n                  <br>\n                  {{entryHp}}\n               </p>\n            </ion-col>\n            <ion-col class=\"statBox\" id=\"atkBox\">\n               <p>\n                  Atk\n                  <br>\n                  {{entryAtk}}\n               </p>\n            </ion-col>\n            <ion-col class=\"statBox\" id=\"defBox\">\n               <p>\n                  Def\n                  <br>\n                  {{entryDef}}\n               </p>\n            </ion-col>\n            <ion-col class=\"statBox\" id=\"sAtkBox\">\n               <p>\n                  SAtk\n                  <br>\n                  {{entrySpecAtk}}\n               </p>\n            </ion-col>\n            <ion-col class=\"statBox\" id=\"sDefBox\">\n               <p>\n                  SDef\n                  <br>\n                  {{entrySpecDef}}\n               </p>\n            </ion-col>\n            <ion-col class=\"statBox\" id=\"spdBox\">\n               <p>\n                  Spd\n                  <br>\n                  {{entrySpd}}\n               </p>\n            </ion-col>\n         </ion-row>\n\n         <hr>\n\n         <ion-row>\n            <ion-col>\n               <ion-card-subtitle class=\"blackText underline\">\n                  Type:\n               </ion-card-subtitle>\n            </ion-col>\n         </ion-row>\n\n         <ion-row>\n            <ion-col>\n               <p class=\"m-0\">\n                  {{entryType}}\n               </p>\n            </ion-col>\n         </ion-row>\n\n         <hr>\n\n         <ion-row>\n            <ion-col>\n               <ion-card-subtitle class=\"blackText underline\">\n                  Abilites:\n               </ion-card-subtitle>\n            </ion-col>\n         </ion-row>\n\n         <ion-row>\n            <ion-col>\n               <p>\n                  {{entryAbility1}}\n               </p>\n            </ion-col>\n\n            <ion-col *ngIf=\"entryAbility2 !== ''\">\n               <p>\n                  {{entryAbility2}}\n               </p>\n            </ion-col>\n         </ion-row>\n\n         <!-- Add EV and evolution sections -->\n\n         <ion-card-content>\n            {{entryDesc}}\n         </ion-card-content>\n      </ion-grid>\n   </ion-card>\n</div>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/components/wild-pokemon/wild-pokemon.component.html":
/*!***********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/wild-pokemon/wild-pokemon.component.html ***!
  \***********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-row>\n   <ion-col class=\"pb-0 \">\n      <img class=\"ion-float-right spriteStyle\" src=\"assets/wildSprites/025.png\" alt=\"Pikachu\"> <!-- Still runs too quickly -->\n   </ion-col>\n</ion-row>\n<ion-row>\n   <ion-col class=\"p-0\">\n      <img class=\"ion-float-left spriteStyle\" src=\"assets/trainerBack.png\" alt=\"Trainer\">\n   </ion-col>\n</ion-row>\n<ion-row>\n   <ion-col class=\"p-0\">\n      <ion-grid class=\"p-0\">\n         <ion-row class=\"battleBox\">\n            <ion-col>\n               <div>\n                  <ion-button (click)='rollWildPokemon()' color=\"warning\" expand=\"block\" class=\"ion-activatable ripple-parent\"> <!-- Set to roll random pokemon -->\n                     Ball\n                     <ion-ripple-effect></ion-ripple-effect>\n                  </ion-button>\n               </div>\n               <div>\n                  <ion-button color=\"warning\" expand=\"block\" class=\"ion-activatable ripple-parent\">\n                     Bait\n                     <ion-ripple-effect></ion-ripple-effect>\n                  </ion-button>\n               </div>\n            </ion-col>\n            <ion-col>\n               <div>\n                  <ion-button color=\"warning\" expand=\"block\" class=\"ion-activatable ripple-parent\">\n                     Rock\n                     <ion-ripple-effect></ion-ripple-effect>\n                  </ion-button>\n               </div>\n               <div>\n                  <ion-button color=\"warning\" expand=\"block\" class=\"ion-activatable ripple-parent\">\n                     Run\n                     <ion-ripple-effect></ion-ripple-effect>\n                  </ion-button>\n               </div>\n            </ion-col>\n         </ion-row>\n      </ion-grid>\n   </ion-col>\n</ion-row>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/explore-container/explore-container.component.html":
/*!**********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/explore-container/explore-container.component.html ***!
  \**********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div>\r\n   <ion-grid>\r\n      <div *ngIf=\"name === 'Tab 1 page'\">\r\n         <div *ngIf=\"stepTest === true; else home\">\r\n            <app-wild-pokemon></app-wild-pokemon>\r\n         </div>\r\n         <ng-template #home>\r\n            <ion-row>\r\n               <ion-col>\r\n                  <ion-button color=\"danger\">WildPokemon</ion-button>\r\n               </ion-col>\r\n            </ion-row>\r\n         </ng-template>\r\n      </div>\r\n\r\n      <div *ngIf=\"name === 'Tab 2 page'\">\r\n         <app-log></app-log>\r\n      </div>\r\n\r\n      <div *ngIf=\"name === 'Tab 3 page'\">\r\n         <p>big ol stinkus3</p>\r\n      </div>\r\n   </ion-grid>\r\n</div>");

/***/ }),

/***/ "./src/app/components/log/log.component.scss":
/*!***************************************************!*\
  !*** ./src/app/components/log/log.component.scss ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvbG9nL2xvZy5jb21wb25lbnQuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/components/log/log.component.ts":
/*!*************************************************!*\
  !*** ./src/app/components/log/log.component.ts ***!
  \*************************************************/
/*! exports provided: LogComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LogComponent", function() { return LogComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var src_app_services_pokedex_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/pokedex.service */ "./src/app/services/pokedex.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _modal_modal_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./modal/modal.component */ "./src/app/components/log/modal/modal.component.ts");





let LogComponent = class LogComponent {
    constructor(pokedex, modalCtrl) {
        this.pokedex = pokedex;
        this.modalCtrl = modalCtrl;
        this.logList = pokedex.returnPokemon();
        console.log(this.logList);
    }
    ngOnInit() { }
    presentModal(pokeSelected) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            console.log(pokeSelected);
            const modal = yield this.modalCtrl.create({
                component: _modal_modal_component__WEBPACK_IMPORTED_MODULE_4__["ModalComponent"],
                componentProps: {
                    entryNum: pokeSelected.dexNum,
                    entryName: pokeSelected.pokemon,
                    entryHp: pokeSelected.hp,
                    entryAtk: pokeSelected.atk,
                    entryDef: pokeSelected.def,
                    entrySpecAtk: pokeSelected.satk,
                    entrySpecDef: pokeSelected.sdef,
                    entrySpd: pokeSelected.spd,
                    entryType: pokeSelected.type,
                    entryAbility1: pokeSelected.ability1,
                    entryAbility2: pokeSelected.ability2,
                    entryEVWorth: pokeSelected.EVWorth,
                    entryGender: pokeSelected.gender,
                    entryEvolvesFrom: pokeSelected.evolvesFrom,
                    entryEvolvesBy: pokeSelected.evolvesBy,
                    entryEvolvesTo: pokeSelected.evolvesTo,
                    entryDesc: pokeSelected.description,
                }
            });
            yield modal.present();
        });
    }
};
LogComponent.ctorParameters = () => [
    { type: src_app_services_pokedex_service__WEBPACK_IMPORTED_MODULE_2__["PokedexService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"] }
];
LogComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-log',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./log.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/components/log/log.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./log.component.scss */ "./src/app/components/log/log.component.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_pokedex_service__WEBPACK_IMPORTED_MODULE_2__["PokedexService"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"]])
], LogComponent);



/***/ }),

/***/ "./src/app/components/log/modal/modal.component.scss":
/*!***********************************************************!*\
  !*** ./src/app/components/log/modal/modal.component.scss ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".dexSprite {\n  width: 8rem;\n  height: auto;\n}\n\nhr {\n  width: 100%;\n}\n\n.cardStyle {\n  color: black;\n}\n\n.modalScroll {\n  overflow-y: auto;\n}\n\n.statBox {\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n          flex-direction: column;\n  -webkit-box-align: center;\n          align-items: center;\n  border-radius: 8px;\n  height: 48px;\n}\n\n#hpBox {\n  background-color: #ff5959;\n}\n\n#atkBox {\n  background-color: #f5ac78;\n}\n\n#defBox {\n  background-color: #fae078;\n}\n\n#sAtkBox {\n  background-color: #9db7f5;\n}\n\n#sDefBox {\n  background-color: #a7db8d;\n}\n\n#spdBox {\n  background-color: #fa92b2;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9sb2cvbW9kYWwvRDpcXENvZGUgU3RhY2tcXEZ1bGwgU3RhY2tcXFNhZmFyaVpvbmVcXFNhZmFyaVpvbmVNS0lJSS9zcmNcXGFwcFxcY29tcG9uZW50c1xcbG9nXFxtb2RhbFxcbW9kYWwuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL2NvbXBvbmVudHMvbG9nL21vZGFsL21vZGFsLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0csV0FBQTtFQUNBLFlBQUE7QUNDSDs7QURHQTtFQUNHLFdBQUE7QUNBSDs7QURHQTtFQUNHLFlBQUE7QUNBSDs7QURHQTtFQUNHLGdCQUFBO0FDQUg7O0FER0E7RUFDRyxvQkFBQTtFQUFBLGFBQUE7RUFDQSw0QkFBQTtFQUFBLDZCQUFBO1VBQUEsc0JBQUE7RUFDQSx5QkFBQTtVQUFBLG1CQUFBO0VBRUEsa0JBQUE7RUFFQSxZQUFBO0FDRkg7O0FES0E7RUFDRyx5QkFBQTtBQ0ZIOztBREtBO0VBQ0cseUJBQUE7QUNGSDs7QURLQTtFQUNHLHlCQUFBO0FDRkg7O0FES0E7RUFDRyx5QkFBQTtBQ0ZIOztBREtBO0VBQ0cseUJBQUE7QUNGSDs7QURLQTtFQUNHLHlCQUFBO0FDRkgiLCJmaWxlIjoic3JjL2FwcC9jb21wb25lbnRzL2xvZy9tb2RhbC9tb2RhbC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5kZXhTcHJpdGV7XHJcbiAgIHdpZHRoOiA4cmVtO1xyXG4gICBoZWlnaHQ6IGF1dG87XHJcbiAgIFxyXG59XHJcblxyXG5ocntcclxuICAgd2lkdGg6IDEwMCU7XHJcbn1cclxuXHJcbi5jYXJkU3R5bGV7XHJcbiAgIGNvbG9yOiBibGFjaztcclxufVxyXG5cclxuLm1vZGFsU2Nyb2xse1xyXG4gICBvdmVyZmxvdy15OiBhdXRvO1xyXG59XHJcblxyXG4uc3RhdEJveHtcclxuICAgZGlzcGxheTogZmxleDtcclxuICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuXHJcbiAgIGJvcmRlci1yYWRpdXM6IDhweDtcclxuXHJcbiAgIGhlaWdodDogNDhweDtcclxufVxyXG5cclxuI2hwQm94e1xyXG4gICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmY1OTU5O1xyXG59XHJcblxyXG4jYXRrQm94e1xyXG4gICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjVhYzc4O1xyXG59XHJcblxyXG4jZGVmQm94e1xyXG4gICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmFlMDc4O1xyXG59XHJcblxyXG4jc0F0a0JveHtcclxuICAgYmFja2dyb3VuZC1jb2xvcjogIzlkYjdmNTtcclxufVxyXG5cclxuI3NEZWZCb3h7XHJcbiAgIGJhY2tncm91bmQtY29sb3I6ICNhN2RiOGQ7XHJcbn1cclxuXHJcbiNzcGRCb3h7XHJcbiAgIGJhY2tncm91bmQtY29sb3I6ICNmYTkyYjI7XHJcbn0iLCIuZGV4U3ByaXRlIHtcbiAgd2lkdGg6IDhyZW07XG4gIGhlaWdodDogYXV0bztcbn1cblxuaHIge1xuICB3aWR0aDogMTAwJTtcbn1cblxuLmNhcmRTdHlsZSB7XG4gIGNvbG9yOiBibGFjaztcbn1cblxuLm1vZGFsU2Nyb2xsIHtcbiAgb3ZlcmZsb3cteTogYXV0bztcbn1cblxuLnN0YXRCb3gge1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBib3JkZXItcmFkaXVzOiA4cHg7XG4gIGhlaWdodDogNDhweDtcbn1cblxuI2hwQm94IHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmNTk1OTtcbn1cblxuI2F0a0JveCB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmNWFjNzg7XG59XG5cbiNkZWZCb3gge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmFlMDc4O1xufVxuXG4jc0F0a0JveCB7XG4gIGJhY2tncm91bmQtY29sb3I6ICM5ZGI3ZjU7XG59XG5cbiNzRGVmQm94IHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2E3ZGI4ZDtcbn1cblxuI3NwZEJveCB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmYTkyYjI7XG59Il19 */");

/***/ }),

/***/ "./src/app/components/log/modal/modal.component.ts":
/*!*********************************************************!*\
  !*** ./src/app/components/log/modal/modal.component.ts ***!
  \*********************************************************/
/*! exports provided: ModalComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ModalComponent", function() { return ModalComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");



let ModalComponent = class ModalComponent {
    constructor(modalCtrl) {
        this.modalCtrl = modalCtrl;
    }
    ngOnInit() { }
    close() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            yield this.modalCtrl.dismiss();
        });
    }
};
ModalComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] }
];
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], ModalComponent.prototype, "pokeData", void 0);
ModalComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-modal',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./modal.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/components/log/modal/modal.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./modal.component.scss */ "./src/app/components/log/modal/modal.component.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]])
], ModalComponent);



/***/ }),

/***/ "./src/app/components/log/modal/modal.module.ts":
/*!******************************************************!*\
  !*** ./src/app/components/log/modal/modal.module.ts ***!
  \******************************************************/
/*! exports provided: ModalModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ModalModule", function() { return ModalModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _modal_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./modal.component */ "./src/app/components/log/modal/modal.component.ts");





let ModalModule = class ModalModule {
};
ModalModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"]
        ],
        declarations: [_modal_component__WEBPACK_IMPORTED_MODULE_4__["ModalComponent"]],
        entryComponents: [_modal_component__WEBPACK_IMPORTED_MODULE_4__["ModalComponent"]],
        exports: [_modal_component__WEBPACK_IMPORTED_MODULE_4__["ModalComponent"]]
    })
], ModalModule);



/***/ }),

/***/ "./src/app/components/wild-pokemon/wild-pokemon.component.scss":
/*!*********************************************************************!*\
  !*** ./src/app/components/wild-pokemon/wild-pokemon.component.scss ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".spriteStyle {\n  width: 50%;\n  height: auto;\n}\n\n.battleBox {\n  border: darkgray 2px dashed;\n  border-radius: 5px;\n  background-color: #0E525C;\n  margin-right: 0.5px;\n  margin-left: 0.5px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy93aWxkLXBva2Vtb24vRDpcXENvZGUgU3RhY2tcXEZ1bGwgU3RhY2tcXFNhZmFyaVpvbmVcXFNhZmFyaVpvbmVNS0lJSS9zcmNcXGFwcFxcY29tcG9uZW50c1xcd2lsZC1wb2tlbW9uXFx3aWxkLXBva2Vtb24uY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL2NvbXBvbmVudHMvd2lsZC1wb2tlbW9uL3dpbGQtcG9rZW1vbi5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNLLFVBQUE7RUFDQSxZQUFBO0FDQ0w7O0FERUE7RUFDSywyQkFBQTtFQUNBLGtCQUFBO0VBQ0EseUJBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0FDQ0wiLCJmaWxlIjoic3JjL2FwcC9jb21wb25lbnRzL3dpbGQtcG9rZW1vbi93aWxkLXBva2Vtb24uY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuc3ByaXRlU3R5bGV7XHJcbiAgICAgd2lkdGg6IDUwJTtcclxuICAgICBoZWlnaHQ6IGF1dG87XHJcbn1cclxuXHJcbi5iYXR0bGVCb3h7XHJcbiAgICAgYm9yZGVyOiBkYXJrZ3JheSAycHggZGFzaGVkO1xyXG4gICAgIGJvcmRlci1yYWRpdXM6IDVweDtcclxuICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMEU1MjVDO1xyXG4gICAgIG1hcmdpbi1yaWdodDogLjVweDtcclxuICAgICBtYXJnaW4tbGVmdDogLjVweDtcclxufSIsIi5zcHJpdGVTdHlsZSB7XG4gIHdpZHRoOiA1MCU7XG4gIGhlaWdodDogYXV0bztcbn1cblxuLmJhdHRsZUJveCB7XG4gIGJvcmRlcjogZGFya2dyYXkgMnB4IGRhc2hlZDtcbiAgYm9yZGVyLXJhZGl1czogNXB4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMEU1MjVDO1xuICBtYXJnaW4tcmlnaHQ6IDAuNXB4O1xuICBtYXJnaW4tbGVmdDogMC41cHg7XG59Il19 */");

/***/ }),

/***/ "./src/app/components/wild-pokemon/wild-pokemon.component.ts":
/*!*******************************************************************!*\
  !*** ./src/app/components/wild-pokemon/wild-pokemon.component.ts ***!
  \*******************************************************************/
/*! exports provided: WildPokemonComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WildPokemonComponent", function() { return WildPokemonComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var src_app_services_pokedex_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/pokedex.service */ "./src/app/services/pokedex.service.ts");



let WildPokemonComponent = class WildPokemonComponent {
    constructor(pokedex) {
        this.pokedex = pokedex;
        this.pokemonList = pokedex.returnPokemon();
        console.log(this.pokemonList);
    }
    ngOnInit() {
        // this.rollWildPokemon();
    }
    rollWildPokemon() {
        this.wildPokemonId = Math.floor(Math.random() * 151) + 1;
        this.wildPokemon = this.pokemonList[this.wildPokemonId - 1]; // Runs too quickly to initialize with the page itself
        console.log(this.wildPokemon);
    }
};
WildPokemonComponent.ctorParameters = () => [
    { type: src_app_services_pokedex_service__WEBPACK_IMPORTED_MODULE_2__["PokedexService"] }
];
WildPokemonComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-wild-pokemon',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./wild-pokemon.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/components/wild-pokemon/wild-pokemon.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./wild-pokemon.component.scss */ "./src/app/components/wild-pokemon/wild-pokemon.component.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_pokedex_service__WEBPACK_IMPORTED_MODULE_2__["PokedexService"]])
], WildPokemonComponent);



/***/ }),

/***/ "./src/app/explore-container/explore-container.component.scss":
/*!********************************************************************!*\
  !*** ./src/app/explore-container/explore-container.component.scss ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("#container strong {\n  font-size: 20px;\n  line-height: 26px;\n}\n\n#container p {\n  font-size: 16px;\n  line-height: 22px;\n  color: #8c8c8c;\n  margin: 0;\n}\n\n#container a {\n  text-decoration: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZXhwbG9yZS1jb250YWluZXIvRDpcXENvZGUgU3RhY2tcXEZ1bGwgU3RhY2tcXFNhZmFyaVpvbmVcXFNhZmFyaVpvbmVNS0lJSS9zcmNcXGFwcFxcZXhwbG9yZS1jb250YWluZXJcXGV4cGxvcmUtY29udGFpbmVyLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9leHBsb3JlLWNvbnRhaW5lci9leHBsb3JlLWNvbnRhaW5lci5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFFQTtFQUNFLGVBQUE7RUFDQSxpQkFBQTtBQ0RGOztBRElBO0VBQ0UsZUFBQTtFQUNBLGlCQUFBO0VBRUEsY0FBQTtFQUVBLFNBQUE7QUNIRjs7QURNQTtFQUNFLHFCQUFBO0FDSEYiLCJmaWxlIjoic3JjL2FwcC9leHBsb3JlLWNvbnRhaW5lci9leHBsb3JlLWNvbnRhaW5lci5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxuXG4jY29udGFpbmVyIHN0cm9uZyB7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgbGluZS1oZWlnaHQ6IDI2cHg7XG59XG5cbiNjb250YWluZXIgcCB7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgbGluZS1oZWlnaHQ6IDIycHg7XG5cbiAgY29sb3I6ICM4YzhjOGM7XG5cbiAgbWFyZ2luOiAwO1xufVxuXG4jY29udGFpbmVyIGEge1xuICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XG59IiwiI2NvbnRhaW5lciBzdHJvbmcge1xuICBmb250LXNpemU6IDIwcHg7XG4gIGxpbmUtaGVpZ2h0OiAyNnB4O1xufVxuXG4jY29udGFpbmVyIHAge1xuICBmb250LXNpemU6IDE2cHg7XG4gIGxpbmUtaGVpZ2h0OiAyMnB4O1xuICBjb2xvcjogIzhjOGM4YztcbiAgbWFyZ2luOiAwO1xufVxuXG4jY29udGFpbmVyIGEge1xuICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XG59Il19 */");

/***/ }),

/***/ "./src/app/explore-container/explore-container.component.ts":
/*!******************************************************************!*\
  !*** ./src/app/explore-container/explore-container.component.ts ***!
  \******************************************************************/
/*! exports provided: ExploreContainerComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ExploreContainerComponent", function() { return ExploreContainerComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let ExploreContainerComponent = class ExploreContainerComponent {
    constructor() {
        this.stepTest = true;
    }
    ngOnInit() { }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
], ExploreContainerComponent.prototype, "name", void 0);
ExploreContainerComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-explore-container',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./explore-container.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/explore-container/explore-container.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./explore-container.component.scss */ "./src/app/explore-container/explore-container.component.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
], ExploreContainerComponent);



/***/ }),

/***/ "./src/app/explore-container/explore-container.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/explore-container/explore-container.module.ts ***!
  \***************************************************************/
/*! exports provided: ExploreContainerComponentModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ExploreContainerComponentModule", function() { return ExploreContainerComponentModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _explore_container_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./explore-container.component */ "./src/app/explore-container/explore-container.component.ts");
/* harmony import */ var _components_wild_pokemon_wild_pokemon_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../components/wild-pokemon/wild-pokemon.component */ "./src/app/components/wild-pokemon/wild-pokemon.component.ts");
/* harmony import */ var _components_log_log_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../components/log/log.component */ "./src/app/components/log/log.component.ts");
/* harmony import */ var _components_log_modal_modal_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../components/log/modal/modal.module */ "./src/app/components/log/modal/modal.module.ts");









let ExploreContainerComponentModule = class ExploreContainerComponentModule {
};
ExploreContainerComponentModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _components_log_modal_modal_module__WEBPACK_IMPORTED_MODULE_8__["ModalModule"]],
        declarations: [_explore_container_component__WEBPACK_IMPORTED_MODULE_5__["ExploreContainerComponent"], _components_wild_pokemon_wild_pokemon_component__WEBPACK_IMPORTED_MODULE_6__["WildPokemonComponent"], _components_log_log_component__WEBPACK_IMPORTED_MODULE_7__["LogComponent"]],
        exports: [_explore_container_component__WEBPACK_IMPORTED_MODULE_5__["ExploreContainerComponent"]]
    })
], ExploreContainerComponentModule);



/***/ }),

/***/ "./src/app/services/pokedex.service.ts":
/*!*********************************************!*\
  !*** ./src/app/services/pokedex.service.ts ***!
  \*********************************************/
/*! exports provided: PokedexService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PokedexService", function() { return PokedexService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");



let PokedexService = class PokedexService {
    constructor(http) {
        this.http = http;
        this.pokemonUrl = 'https://spreadsheets.google.com/feeds/list/1cMgd1ABRtTlwTstgGwEf563_ZTfZhLBCPJqvpl0ysTY/1/public/full?alt=json';
        this.pokedexEntryList = [];
        this.getPokemon();
    }
    getPokemon() {
        this.pokeDataSheet = this.http.get(this.pokemonUrl);
        this.pokeDataSheet.subscribe(x => {
            // console.log(x);
            for (let p of x.feed.entry) {
                let nextPokemon = {
                    dexNum: p.gsx$dexnum.$t,
                    pokemon: p.gsx$pokemon.$t,
                    hp: p.gsx$hp.$t,
                    atk: p.gsx$atk.$t,
                    def: p.gsx$def.$t,
                    satk: p.gsx$sa.$t,
                    sdef: p.gsx$sd.$t,
                    spd: p.gsx$spd.$t,
                    type: p.gsx$type1.$t,
                    ability1: p.gsx$ability1.$t,
                    ability2: p.gsx$ability2.$t,
                    EVWorth: p.gsx$evworth.$t,
                    gender: p.gsx$gender.$t,
                    evolvesFrom: p.gsx$evolvesfrom.$t,
                    evolvesBy: p.gsx$evolvesby.$t,
                    evolvesTo: p.gsx$evolvesto.$t,
                    discovered: p.gsx$discovered.$t,
                    description: p.gsx$description.$t,
                };
                this.pokedexEntryList.push(nextPokemon);
            }
            console.log(this.pokedexEntryList);
        });
    }
    returnPokemon() {
        return this.pokedexEntryList;
    }
};
PokedexService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
PokedexService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
], PokedexService);



/***/ })

}]);
//# sourceMappingURL=default~tab1-tab1-module~tab2-tab2-module~tab3-tab3-module-es2015.js.map