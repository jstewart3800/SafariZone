import { Component, OnInit } from '@angular/core';

import { PokedexService } from 'src/app/services/pokedex.service';
import { PokedexEntry } from 'src/app/interfaces/pokedex-entry';
import { ModalController } from '@ionic/angular';
import { ModalComponent } from './modal/modal.component';
import { HttpClient } from '@angular/common/http';
import { CaughtLog } from 'src/app/interfaces/caught-log';

@Component({
   selector: 'app-log',
   templateUrl: './log.component.html',
   styleUrls: ['./log.component.scss'],
})
export class LogComponent implements OnInit {

   pokemonName = 'Pikachu';

   private discovered = false;

   private userCaughtList = [];
   private userCaughtObj = {};

   private logList: PokedexEntry[];

   public loggedInUserUrl = this.pokedex.apiUrl + `pokemoncaught/${this.pokedex.loggedInUser.userEmail}`;

   constructor(private pokedex: PokedexService, public modalCtrl: ModalController, private http: HttpClient) {
      this.logList = pokedex.returnPokemon();
      console.log(this.logList);
   }

   ngOnInit() {
      this.GetUserLog();
   }

   async presentModal(pokeSelected: PokedexEntry) {
      console.log(pokeSelected);
      const modal = await this.modalCtrl.create({
         component: ModalComponent,
         componentProps: { // an object where each key in the object maps to an input of an associated component
            entryNum: pokeSelected.dexNum,
            entryName: pokeSelected.pokemon,
            entryHp: pokeSelected.hp,
            entryAtk: pokeSelected.atk,
            entryDef: pokeSelected.def,
            entrySpecAtk: pokeSelected.satk,
            entrySpecDef: pokeSelected.sdef,
            entrySpd: pokeSelected.spd,
            entryType: pokeSelected.type,
            entryAbility1: pokeSelected.ability1,
            entryAbility2: pokeSelected.ability2,
            entryEVWorth: pokeSelected.EVWorth,
            entryGender: pokeSelected.gender,
            entryEvolvesFrom: pokeSelected.evolvesFrom,
            entryEvolvesBy: pokeSelected.evolvesBy,
            entryEvolvesTo: pokeSelected.evolvesTo,
            entryDesc: pokeSelected.description,
         }
      });
      await modal.present();
   }

   GetUserLog() {
      this.http.get(this.loggedInUserUrl).subscribe(l => {
         console.log(this.loggedInUserUrl);
         console.log(l);
         this.userCaughtList.push(l);
         console.log(this.userCaughtList);
      })
   }

   pokemonCaught(pokeCaught: string) { // Real function will use passed in name
      if(pokeCaught === 'Pikachu'){
         this.userCaughtObj = {
            id: 0,
            userEmail: this.pokedex.loggedInUser.userEmail,
            Bulbasaur: false,
         Ivysaur: false,
         Venusaur: false,
         Charmander: false,
         Charmeleon: false,
         Charizard: false,
         Squirtle: false,
         Wartortle: false,
         Blastoise: false,
         Caterpie: false,
         // Metapod = Metap,
         // Butterfree = Butterfr,
         // Weedle = Weed,
         // Kakuna = Kaku,
         // Beedrill = Beedri,
         // Pidgey = Pidg,
         // Pidgeotto = Pidgeot,
         // Pidgeot = Pidge,
         // Rattata = Ratta,
         // Raticate = Ratica,
         // Spearow = Spear,
         // Fearow = Fear,
         // Ekans = Eka,
         // Arbok = Arb,
         // Pikachu = Pikac,
         // Raichu = Raic,
         // Sandshrew = Sandshr,
         // Sandslash = Sandsla,
         // NidoranF = Nidora,
         // Nidorina = Nidori,
         // Nidoqueen = Nidoque,
         // NidoranM = Nidora,
         // Nidorino = Nidori,
         // Nidoking = Nidoki,
         // Clefairy = Clefai,
         // Clefable = Clefab,
         // Vulpix = Vulp,
         // Ninetales = Ninetal,
         // Jigglypuff = Jigglypu,
         // Wigglytuff = Wigglytu,
         // Zubat = Zub,
         // Golbat = Golb,
         // Oddish = Oddi,
         // Gloom = Glo,
         // Vileplume = Vileplu,
         // Paras = Par,
         // Parasect = Parase,
         // Venonat = Venon,
         // Venomoth = Venomo,
         // Diglett = Digle,
         // Dugtrio = Dugtr,
         // Meowth = Meow,
         // Persian = Persi,
         // Psyduck = Psydu,
         // Golduck = Goldu,
         // Mankey = Mank,
         // Primeape = Primea,
         // Growlithe = Growlit,
         // Arcanine = Arcani,
         // Poliwag = Poliw,
         // Poliwhirl = Poliwhi,
         // Poliwrath = Poliwra,
         // Abra = Ab,
         // Kadabra = Kadab,
         // Alakazam = Alakaz,
         // Machop = Mach,
         // Machoke = Macho,
         // Machamp = Macha,
         // Bellsprout = Bellspro,
         // Weepinbell = Weepinbe,
         // Victreebell = Victree,be
         // Tentacool = Tentaco,
         // Tentacruel = Tentacru,
         // Geodude = Geodu,
         // Graveler = Gravel,
         // Golem = Gol,
         // Ponyta = Pony,
         // Rapidash = Rapida,
         // Slowpoke = Slowpo,
         // Slowbro = Slowb,
         // Magnemite = Magnemi,
         // Magneton = Magnet,
         // Farfetchd = Farfetc,
         // Doduo = Dod,
         // Dodrio = Dodr,
         // Seel = Se,
         // Dewgong = Dewgo,
         // Grimer = Grim,
         // Muk = M,
         // Shellder = Shelld,
         // Cloyster = Cloyst,
         // Gastly = Gast,
         // Haunter = Haunt,
         // Gengar = Geng,
         // Onix = On,
         // Drowzee = Drowz,
         // Hypno = Hyp,
         // Krabby = Krab,
         // Kingler = Kingl,
         // Voltorb = Volto,
         // Electrode = Electro,
         // Exeggcute = Exeggcu,
         // Exeggutor = Exeggut,
         // Cubone = Cubo,
         // Marowak = Marow,
         // Hitmonlee = Hitmonl,
         // Hitmonchan = Hitmonch,
         // Lickitung = Lickitu,
         // Koffing = Koffi,
         // Weezing = Weezi,
         // Rhyhorn = Rhyho,
         // Rhydon = Rhyd,
         // Chansey = Chans,
         // Tangela = Tange,
         // Kangaskhan = Kangaskh,
         // Horsea = Hors,
         // Seadra = Sead,
         // Goldeen = Golde,
         // Seaking = Seaki,
         // Staryu = Star,
         // Starmie = Starm,
         // MrMime = MrMi,
         // Scyther = Scyth,
         // Jynx = Jy,
         // Electabuzz = Electabu,
         // Magmar = Magm,
         // Pinsir = Pins,
         // Tauros = Taur,
         // Magikarp = Magika,
         // Gyarados = Gyarad,
         // Lapras = Lapr,
         // Ditto = Dit,
         // Eevee = Eev,
         // Vaporeon = Vapore,
         // Jolteon = Jolte,
         // Flareon = Flare,
         // Porygon = Poryg,
         // Omanyte = Omany,
         // Omastar = Omast,
         // Kabuto = Kabu,
         // Kabutops = Kabuto,
         // Aerodactyl = Aerodact,
         // Snorlax = Snorl,
         // Articuno = Articu,
         // Zapdos = Zapd,
         // Moltres = Moltr,
         // Dratini = Drati,
         // Dragonair = Dragona,
         // Dragonite = Dragoni,
         // Mewtwo = Mewt,
         // Mew = 
         }
      }
   }
}

