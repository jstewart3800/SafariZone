import { Component } from '@angular/core';
import { PokedexService } from '../services/pokedex.service';
import { ModalController } from '@ionic/angular';
import { ModalComponent } from '../components/modal/modal.component';

@Component({
   selector: 'app-home',
   templateUrl: 'home.page.html',
   styleUrls: ['home.page.scss'],
})
export class HomePage {

   private logList;

   constructor(private pokedex: PokedexService, public modalController: ModalController) {
      this.logList = pokedex.returnPokemon();
      console.log(this.logList);
   }

   async presentModal() {
      const modal = await this.modalController.create({
         component: ModalComponent
      });
      return await modal.present();
   }
}
