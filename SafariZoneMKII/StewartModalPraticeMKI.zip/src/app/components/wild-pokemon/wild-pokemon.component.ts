import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wild-pokemon',
  templateUrl: './wild-pokemon.component.html',
  styleUrls: ['./wild-pokemon.component.scss'],
})
export class WildPokemonComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
